package tk.macoz.blog.demo.Models;

public class Contact {
}
